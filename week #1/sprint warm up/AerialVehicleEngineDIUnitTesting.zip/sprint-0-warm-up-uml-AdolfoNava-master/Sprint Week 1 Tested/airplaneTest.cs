﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Sprint_Week_1_Tested
{
    class airplaneTest
    {
    }
}
