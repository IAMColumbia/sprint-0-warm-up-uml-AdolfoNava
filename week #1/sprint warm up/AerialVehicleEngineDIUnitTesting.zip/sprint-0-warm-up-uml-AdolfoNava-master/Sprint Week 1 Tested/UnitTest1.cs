using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Sprint_Week_1_Tested
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
