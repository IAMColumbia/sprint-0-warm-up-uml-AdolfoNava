﻿namespace Sprint_0_Warm_Up
{
    public interface IAboutable
    {
        public string About();
    }
}