﻿using Sprint_0_Warm_Up.Engines;
using System;
using static System.Console;
using Ninject;
using Ninject.Modules;
using Sprint_0_Warm_Up.NinjectModules;

namespace Sprint_0_Warm_Up
{
    class Program
    {
        
        static void Main(string[] args)
        {
            //Tester t = new Tester();
            //t.Test();
            IAerialVehicle ap;
            IKernel kernal;
            kernal = new StandardKernel(new AirplaneNinject());
            ap = kernal.Get<IAerialVehicle>();
            Console.WriteLine(ap.Engine.About()); 
        }

        class Tester
        {
            public void Test()
            {
                /*
                WriteLine("Flying Vehicle Tester......................................................");
                WriteLine("\nAirlplane.cs...............................................................");


                Airplane ap = new Airplane();
                WriteLine(ap.About());

                WriteLine("\nAireplaneTakeOffTests...............................................................");
                WriteLine("\nCall ap.TakeOff():");
                WriteLine(ap.TakeOff());
                WriteLine("\nCall ap.StartEngine():");
                ap.StartEngine();
                WriteLine(ap.TakeOff());


                //Fly up
                WriteLine("\nFly up Tests...................................................................");
                WriteLine("Call ap.FlyUp() fly to 1,000ft default");
                ap.FlyUp();
                WriteLine(ap.About());
                WriteLine("\nCall ap.FlyUp(44000) Fly up to 45,000ft:");
                ap.FlyUp(44000);
                WriteLine(ap.About());
                WriteLine("\nCall ap.FlyUp(44000) Fly up another 40,000ft shouldn't work");
                ap.FlyUp(40000);
                WriteLine(ap.About());

                WriteLine("\nFly Down.................................................................");
                WriteLine("Call ap.FlyDown(50000) Fly Down 50,000 ft");
                ap.FlyDown(50000);
                WriteLine(ap.About());
                WriteLine("Call ap.FlyDown(ap.CurrentAltitude) this should land");
                ap.FlyDown(ap.CurrentAltitude);
                WriteLine(ap.About());
            
                */
            }
        }
    }
}

