﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace MakeingTestFromGroundUp
{
    //fail
    class CreatingThreeWayGame
    {
        public void Play()
        {

            

        }
    }
}
