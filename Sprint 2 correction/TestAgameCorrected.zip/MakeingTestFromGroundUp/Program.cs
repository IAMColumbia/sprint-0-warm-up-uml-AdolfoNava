﻿using System;

namespace MakeingTestFromGroundUp
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
