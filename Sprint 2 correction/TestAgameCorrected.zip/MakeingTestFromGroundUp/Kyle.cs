﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MakeingTestFromGroundUp
{
    public class Kyle : People
    {
        public Kyle()
        {
            this.Name = "Kyle";
            this.Power = 50;
            this.AttackType = "Bubbles";
            this.Health = 6000;

        }


    }
}
