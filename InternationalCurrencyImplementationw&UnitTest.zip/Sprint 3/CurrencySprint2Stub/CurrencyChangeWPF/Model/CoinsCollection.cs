﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Currency;
using Currency.US;

namespace CurrencyChangeWPF.Model
{
    public class CoinsCollection
    {
        public USCurrencyRepo cr;
        SaveableCurrencyRepo scr;
        public decimal total { get; set; }
        public decimal makingchange { get; set; }
        public List<ICoin> coins
        {
            get { return cr.Coins; }
            set { cr.Coins = value; }
        }
        protected Guid id;
        public CoinsCollection()
        {
            this.cr = new USCurrencyRepo();
            this.total = 0;
            this.id = new Guid();
            this.makingchange = 0.00M;
            this.coins = cr.Coins;
            this.scr = new SaveableCurrencyRepo(cr);
        }

        public void AddDollarCoin()
        {
             cr.AddCoin(new DollarCoin());
        }
        public void AddHalfDollar()
        {            
            cr.AddCoin(new HalfDollar());
        }
        public void AddQuarter()
        {
            cr.AddCoin(new Quarter());
        }
        public void AddDime()
        {
            cr.AddCoin(new Dime());
        }
        public void AddNickel()
        {
            cr.AddCoin(new Nickel());
        }
        public void AddPenny()
        {
            cr.AddCoin(new Penny());
        }
        public decimal TotalChange()
        {
            total = cr.TotalValue();
            return total;
        }
        public void ClearCollection()
        {
            cr.ClearChange();
        }
        public void SerializeSave()
        {            
            scr.SavableCoins = coins;
            scr.Save();
        }
        public void SerializeLoad()
        {
            cr.ClearChange();
            scr.Load();
            coins = scr.Coins;
        }
        public void MakeChange(decimal change)
        {
            makingchange = change;
            cr.ClearChange();
            cr.MakeChange(makingchange);
        }
    }
}
