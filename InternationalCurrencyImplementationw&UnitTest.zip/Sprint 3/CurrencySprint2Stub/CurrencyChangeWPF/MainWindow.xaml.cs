﻿using Currency;
using CurrencyChangeWPF.Model;
using CurrencyChangeWPF.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CurrencyChangeWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// There was some special errors that I was getting when I was debugging that weren't specified but at the iam tutoring center 
    /// Derrickson, Austin helped me understand what caused that error but now there is the serialization error now that couldn't be figured out by the tutors
    /// Now I am just gonna submit as is and I really want to contact you to go over xaml/xml stuff before we have to deal with this again.
    /// 
    public partial class MainWindow : Window
    {
        CoinsCollection cc;
        CoinsCollection mcc;
        CoinDepositViewModel cdvm;
        MakingChangeViewModel crvm;
        public MainWindow()
        {
            cc = new CoinsCollection();
            mcc = new CoinsCollection();
            cdvm = new CoinDepositViewModel(cc);
            crvm = new MakingChangeViewModel(mcc);
            InitializeComponent();
        }

        private void UserControlCurrencyRepo_Loaded(object sender, RoutedEventArgs e)
        {
            UserControlCurrencyRepo.DataContext = cdvm;
        }

        private void UserControlMakingChange_Loaded_1(object sender, RoutedEventArgs e)
        {
            UserControlMakingChange.DataContext = crvm;
        }
    }
}
