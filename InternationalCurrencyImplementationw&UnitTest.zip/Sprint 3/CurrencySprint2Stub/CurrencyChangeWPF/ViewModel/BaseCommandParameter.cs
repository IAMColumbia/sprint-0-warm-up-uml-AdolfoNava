﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyChangeWPF.ViewModel
{
    public class BaseCommandParameter
    {
        private Action<object> commandAction;

        public event EventHandler CanExecuteChanged = (sender, e) => { };

        public BaseCommandParameter
            (Action<object> action)
        {
            commandAction = action;
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            commandAction(parameter);
        }
    }
}
