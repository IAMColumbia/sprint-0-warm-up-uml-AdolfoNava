﻿using Currency;
using CurrencyChangeWPF.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace CurrencyChangeWPF.ViewModel
{
    class MakingChangeViewModel : BaseViewModel
    {
        CoinsCollection mcc;
        public decimal makingchange
        {
            get { return mcc.makingchange; }
            set { mcc.makingchange = value; RaisePropertyChangedEvent(); }
        }
        public List<ICoin> coinsfromchange
        {
            get { return mcc.coins; }
            set { mcc.coins = value; RaisePropertyChangedEvent(); }
        }
        public ICommand MakingChangeCommand { get; set; }

        public MakingChangeViewModel(CoinsCollection c)
        {
            this.mcc = c;            
            this.MakingChangeCommand = new BaseCommand(MakeChange);
        }
        protected void MakeChange()
        {
            mcc.MakeChange(makingchange);
            RaisePropertyChangedEvent("coinsfromchange");
        }
    }
}
