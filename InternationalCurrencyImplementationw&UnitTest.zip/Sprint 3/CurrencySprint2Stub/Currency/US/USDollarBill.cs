﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Currency.US
{
    public class USDollarBill : USBankNote
    {
        public USDollarBill()
        {
           
        }
    }
}