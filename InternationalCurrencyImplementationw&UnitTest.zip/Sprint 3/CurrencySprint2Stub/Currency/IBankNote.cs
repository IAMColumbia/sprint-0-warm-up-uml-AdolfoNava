﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Currency
{
    public interface IBankNote : ICurrency
    {
        
    }
}
