﻿using Currency;
using Currency.JP;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestsCurrency
{
    [TestClass]
    public class JPYenCoinTests
    {
        ICoin one,ten,fivehundred;
        FiveYen five;
        [TestMethod]
        public void YenConstructor()
        {
            //Arrange
            one = new OneYen();
            fivehundred = new FiveHundredYen();
            //Act

            //Assert
            Assert.AreEqual(System.DateTime.Now.Year, one.Year);
            Assert.AreEqual(1M, one.MonetaryValue);
            Assert.AreEqual(System.DateTime.Now.Year, fivehundred.Year);
            Assert.AreEqual(500, fivehundred.MonetaryValue);

        }
        [TestMethod]
        public void YenAbout()
        {
            one = new OneYen();

            string about = "Japan's one yen coin was made in 2021. It is worth ¥1. It was made in Hiroshima.";

            Assert.AreEqual(about, one.About());
        }
        [TestMethod]
        public void FakeYenAbout()
        {
            var mockone = new Mock<ICoin>();
            one = new OneYen();

            mockone.Setup(one => one.Year).Returns(System.DateTime.Now.Year);
            mockone.Setup(one => one.MonetaryValue).Returns(1M);
            mockone.Setup(one => one.About()).Returns(one.About());

            Assert.AreEqual(one.About(), mockone.Object.About());
        }
        [TestMethod]
        public void YenConstructorOverload()
        {
            //Act
            var fiveyen = new FiveYen(CoinMaterial.Brass);
            five = new FiveYen();


            //Arrange

            //Assert
            Assert.AreEqual(fiveyen.Coinmaterial, five.Coinmaterial);

        }
        [TestMethod]
        public void FakeYenConstructor()
        {
            //Arrange
            var mock10yen = new Mock<ICoin>();
            ten = new TenYen();
            //Act
            mock10yen.Setup(ten => ten.Name).Returns("Ten Yen");
            //Assert
            Assert.AreEqual(ten.Name,mock10yen.Object.Name);
        }
        [TestMethod]
        public void JPCoinMaterial()
        {
            string cmnameA, cmnameBra, cmnameBron, cmnameC, cmnameNB;
            CoinMaterial a, bra, bron, c, nb;

            cmnameA = "Aluminum";
            cmnameBra = "Brass";
            cmnameBron = "Bronze";
            cmnameC = "Cupronickel";
            cmnameNB = "Nickel-Brass";


            a = Currency.JP.CoinMaterial.Aluminum;
            bra = Currency.JP.CoinMaterial.Brass;
            bron = Currency.JP.CoinMaterial.Bronze;
            c = CoinMaterial.Cupronickel;
            nb = CoinMaterial.Nickel_Brass;


            Assert.AreEqual(JPCoin.GetNameforCoinMaterial(a),cmnameA); 
            Assert.AreEqual(JPCoin.GetNameforCoinMaterial(bra), cmnameBra);
            Assert.AreEqual(JPCoin.GetNameforCoinMaterial(bron), cmnameBron);
            Assert.AreEqual(JPCoin.GetNameforCoinMaterial(c), cmnameC);
            Assert.AreEqual(JPCoin.GetNameforCoinMaterial(nb), cmnameNB);
        }
        //Can't instaniate a enum into mock object because 1. its not part of an interface its further down in the inheritance tree 2. get exception when I do a direct instaniate 
        //[TestMethod]
        //public void FakeJPCoinMaterial()
        //{
        //    string cmnameNB, cmnamefromMock;
        //    CoinMaterial nb;
        //    var cmcall = new Mock<JPCoin>();

        //    cmnameNB = "Nickel-Brass";
        //    nb = Currency.JP.CoinMaterial.Nickel_Brass;
        //    //this one tries to setup like the fakeyencontructor test but it doesn't treat the enum variable the same way
        //    cmcall.SetupGet(cm => cm.GetCoinMaterial(nb)).Returns(nb);
        //    cmnamefromMock = JPCoin.GetNameforCoinMaterial(cmcall.Object.Coinmaterial);



        //    Assert.AreEqual(cmnameNB, cmnamefromMock);
        //}
    }
}
