﻿using Currency;
using Currency.JP;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestsCurrency
{
    [TestClass]
    public class JPCurrencyRepoTest
    {
        JPCurrencyRepo jpcr;
        SaveableCurrencyRepo scr;
        public JPCurrencyRepoTest()
        {
            
        }
        [TestMethod]
        public void JPCoinAdd()
        {
            //Arrange
            jpcr = new JPCurrencyRepo();
            var jpcrtest = new JPCurrencyRepo();
            decimal direct, methodway;

            //Act
            jpcr.Coins.Add(new OneYen());
            jpcrtest.AddCoin(new OneYen());

           direct = jpcr.TotalValue();
            methodway = jpcrtest.TotalValue();

            //Assert
            Assert.AreEqual(direct, methodway);
            Assert.AreEqual(jpcr.Coins.Count, jpcrtest.Coins.Count);

        }
        [TestMethod]
        public void FakeJPCoinAdd()
        {
            //Arrange
            var mockcoin = new Mock<ICoin>();
            mockcoin.SetupGet(m => m.Name).Returns("One Yen");
            mockcoin.SetupGet(m => m.MonetaryValue).Returns(1M);
            mockcoin.SetupGet(m => m.Year).Returns(2021);

            //Act
            jpcr = new JPCurrencyRepo();
            jpcr.AddCoin(mockcoin.Object);
            
            //Can't put .returns(c) because its void but either approach leads to an exception
            //mockcr.Setup(cr => cr.AddCoin(c));

            //Assert
            Assert.AreEqual(jpcr.TotalValue(),mockcoin.Object.MonetaryValue);
        }
        [TestMethod]
        public void JPCoinRemove()
        {
            //Arrange
            jpcr = new JPCurrencyRepo();
            var jpcrtest = new JPCurrencyRepo();
            ICoin five = new FiveYen();

            //Act
            jpcr.AddCoin(new FiveYen());
            jpcrtest.AddCoin(new FiveYen());
            //Assert
            Assert.AreEqual(jpcr.Coins.Count, jpcrtest.Coins.Count);
            jpcr.RemoveCoin(five);
            jpcrtest.Coins.Remove(five);
            Assert.AreEqual(jpcrtest.GetCoinCount(), jpcr.GetCoinCount());
        }
        [TestMethod]//can't test this if not even the mock approach can add a coin with either method
        public void FakeJPCoinRemove()
        {
            //Arrange
            var mockcoin = new Mock<ICoin>();
            mockcoin.SetupGet(m => m.Name).Returns("One Yen");
            mockcoin.SetupGet(m => m.MonetaryValue).Returns(1M);
            mockcoin.SetupGet(m => m.Year).Returns(2021);

            //Act
            jpcr = new JPCurrencyRepo();
            jpcr.AddCoin(mockcoin.Object);


            //Assert
            Assert.AreEqual(jpcr.TotalValue(), mockcoin.Object.MonetaryValue);
            jpcr.RemoveCoin(mockcoin.Object);
            Assert.AreEqual(jpcr.TotalValue(), mockcoin.Object.MonetaryValue - 1M);
        }
        [TestMethod]
        public void JPMakeChangeTest()
        {
            //Arrange
            jpcr = new JPCurrencyRepo();

            //Act
            jpcr.MakeChange(73366);

            //Assert
            Assert.AreEqual(73366, jpcr.TotalValue());

        }
        //this can't be tested because the method MakeChange is a void method that gathers coins in while loops and the new coins are not saved into the list and gets lost in transition
        //[TestMethod]
        //public void FakeJPMakeChangeTest()
        //{
        //    decimal valuenormal, valuemock;
        //    //Arrange
        //    var mockmc = new Mock<JPCurrencyRepo>();
        //    jpcr = new JPCurrencyRepo();

        //    //Act

        //    jpcr.MakeChange(73366);
        //    mockmc.Setup(mc => mc.MakeChange(73366));

        //    //jpcr.TotalValue()
        //    //Assert
        //    //this one probably doesn't work because it calls a method that adds objects to a list and isn't mocked in but can't be done to check the coins count either
        //    Assert.AreEqual(jpcr.Coins.Count, mockmc.Object.Coins.Count);
        //}
        [TestMethod]
        public void USDtoJPTest()
        {
            jpcr = new JPCurrencyRepo();

            jpcr.USDtoJP(5.00M);
            //this conversion rate is from april 8, 2021 because the rate fluctuates daily by some
            //margins that would make testing it a problem unless i call for an api conversion rate that will always keep it updated
            Assert.AreEqual(546M, jpcr.TotalValue());
        }
        [TestMethod]
        public void SaveSerialization()
        {
            jpcr = new JPCurrencyRepo();
            jpcr.Coins.Add(new OneYen());
            scr = new SaveableCurrencyRepo(jpcr);
            JPCurrencyRepo jpcrloaded = new JPCurrencyRepo();
            var scrload = new SaveableCurrencyRepo(jpcr);
            scr.Save();
            scrload.Load();
            Assert.AreEqual(scrload.Coins.Count, scr.Coins.Count);
        }
    }
}
