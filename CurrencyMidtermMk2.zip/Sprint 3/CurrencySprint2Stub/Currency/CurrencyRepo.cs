﻿using Currency.US;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Currency
{
    [Serializable]
    public class CurrencyRepo : ICurrencyRepo
    {
        public List<ICoin> Coins { get; set; }
        double total;

        public CurrencyRepo()
        {
            this.Coins = new List<ICoin>();
        }


        public void AddCoin(ICoin c)
        {
            Coins.Add(c);
        }

        public int GetCoinCount()
        {
            int count = 0;
            foreach (Coin c in Coins)
            {
                count++;
            }
            return count;
        }

        public void MakeChange(double Amount)
        {
            //CurrencyRepo cr = new CurrencyRepo();
            while (Amount >= 1.0)
            {
                Coins.Add(new DollarCoin());
                Amount -= 1.0;
            }
            while (Amount >= .50)
            {
                Coins.Add(new HalfDollar());
                Amount -= 0.50;
            }
            while (Amount >= .25)
            {
                Coins.Add(new Quarter());
                Amount -= 0.25;
            }
            while (Amount >= .10)
            {
                Coins.Add(new Dime());
                Amount -= 0.10;
            }
            while (Amount >= .05)
            {
                Coins.Add(new Nickel());
                Amount -= 0.05;
            }
            while (Amount > .00)
            {
                Coins.Add(new Penny());
                Amount -= 0.01;
            }
            //return cr;
        }

        public ICurrencyRepo MakeChange(double AmountTendered, double TotalCost)
        {
            throw new NotImplementedException();
        }

        public ICoin RemoveCoin(ICoin c)
        {
            Coins.Remove(c);
            return c;

        }

        public double TotalValue()
        {
            total = 0;
            foreach (Coin c in Coins)
            {
                total += c.MonetaryValue;
            }
            return total;
        }

        public string About()
        {
            return "";
        }

        public ICurrencyRepo CreateChange(double Amount)
        {
            CurrencyRepo cr = new CurrencyRepo();
            switch (Amount)
            {
                case 2.0:
                    cr.Coins.Add(new DollarCoin());
                    cr.Coins.Add(new DollarCoin());
                    break;
                case 1.5:
                    cr.Coins.Add(new DollarCoin());
                    cr.Coins.Add(new HalfDollar());
                    break;
                case .75:
                    cr.Coins.Add(new HalfDollar());
                    cr.Coins.Add(new Quarter());
                    break;
                case .11:
                    cr.Coins.Add(new Dime());
                    cr.Coins.Add(new Penny());
                    break;
                case .06:
                    cr.Coins.Add(new Nickel());
                    cr.Coins.Add(new Penny());
                    break;
                case .04:
                    cr.Coins.Add(new Penny());
                    cr.Coins.Add(new Penny());
                    cr.Coins.Add(new Penny());
                    cr.Coins.Add(new Penny());
                    break;
                default:
                    break;
            }

            return cr;

        }
        public void ClearChange()
        {
            Coins.Clear();
        }

        public ICurrencyRepo CreateChange(double AmountTendered, double TotalCost)
        {
            throw new NotImplementedException();
        }


    }
}
