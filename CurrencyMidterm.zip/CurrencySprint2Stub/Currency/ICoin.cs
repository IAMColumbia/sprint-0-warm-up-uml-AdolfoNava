﻿namespace Currency
{
    public interface ICoin : ICurrency
    {
        int Year { get; set; }
    }
}