﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Currency;
using Currency.US;

namespace CurrencyChangeWPF.Model
{
    public class CoinsCollection
    {
        public CurrencyRepo cr;
        public double total { get; set; }
        public double makingchange { get; set; }
        public List<ICoin> coins
        {
            get { return cr.Coins; }
            set { cr.Coins = value; }
        }
        protected Guid id;
        public CoinsCollection()
        {
            this.cr = new CurrencyRepo();
            this.total = 0;
            this.id = new Guid();
            this.makingchange = 0.00;
            this.coins = cr.Coins;
        }

        public void AddDollarCoin()
        {
             cr.AddCoin(new DollarCoin());
        }
        public void AddHalfDollar()
        {            
            cr.AddCoin(new HalfDollar());
        }
        public void AddQuarter()
        {
            cr.AddCoin(new Quarter());
        }
        public void AddDime()
        {
            cr.AddCoin(new Dime());
        }
        public void AddNickel()
        {
            cr.AddCoin(new Nickel());
        }
        public void AddPenny()
        {
            cr.AddCoin(new Penny());
        }
        public double TotalChange()
        {
            total = cr.TotalValue();
            return total;
        }
        public void ClearCollection()
        {
            cr.ClearChange();
        }
        public void SerializeSave()
        {
            cr.Save("test.xml");
        }
        public void SerializeLoad()
        {

        }
        public void MakeChange(double change)
        {
            makingchange = change;
            cr.ClearChange();
            cr.MakeChange(makingchange);
        }
    }
}
