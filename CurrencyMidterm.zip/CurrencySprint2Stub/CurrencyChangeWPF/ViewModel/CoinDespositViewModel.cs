﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Currency;
using CurrencyChangeWPF.Model;

namespace CurrencyChangeWPF.ViewModel
{
    public class CoinDepositViewModel : BaseViewModel
    {
        CoinsCollection cc;
        public double total
        {
            get { return cc.total; }
            set { cc.total = value; RaisePropertyChangedEvent(); }
        }
        public double makingchange 
        {
            get { return cc.makingchange; }
            set { cc.makingchange = value;RaisePropertyChangedEvent(); }
        }
        public List<ICoin> coins
        {
            get { return cc.coins; }
            set { cc.coins = value; RaisePropertyChangedEvent(); }
        }
        public ICommand AddDollarCoinCommand { get; set; }
        public ICommand AddHalfDollarCommand { get; set; }
        public ICommand AddQuarterCommand { get; set; }
        public ICommand AddDimeCommand { get; set; }
        public ICommand AddNickelCommand { get; set; }
        public ICommand AddPennyCommand { get; set; }
        public ICommand ClearCollectionCommand { get; set; }
        public ICommand SerializeSaveCommand { get; set; }
        public ICommand SerializeLoadCommand { get; set; }
        public ICommand MakingChangeCommand { get; set; }
        public CoinDepositViewModel(CoinsCollection c)
        {
            this.cc = c;
            this.AddDollarCoinCommand = new BaseCommand(AddDollarCoin);
            this.AddHalfDollarCommand = new BaseCommand(AddHalfDollar);
            this.AddQuarterCommand = new BaseCommand(AddQuarter);
            this.AddDimeCommand = new BaseCommand(AddDime);
            this.AddNickelCommand = new BaseCommand(AddNickel);
            this.AddPennyCommand = new BaseCommand(AddPenny);
            this.ClearCollectionCommand = new BaseCommand(NewSerialize);
            this.SerializeSaveCommand = new BaseCommand(SaveSerialize);
            this.SerializeLoadCommand = new BaseCommand(LoadSerialize);
            this.MakingChangeCommand = new BaseCommand(MakeChange);
        }

        protected void AddDollarCoin()
        {
            cc.AddDollarCoin();
            cc.total = cc.TotalChange();
            RaisePropertyChangedEvent("total");
        }
        protected void AddHalfDollar()
        {
            cc.AddHalfDollar();
            cc.total = cc.TotalChange();
            RaisePropertyChangedEvent("total");
        }
        protected void AddQuarter()
        {
            cc.AddQuarter(); cc.total = cc.TotalChange();
            RaisePropertyChangedEvent("total");
        }
        protected void AddDime()
        {
            cc.AddDime();
            cc.total = cc.TotalChange();
            RaisePropertyChangedEvent("total");
        }
        protected void AddNickel()
        {
            cc.AddNickel();
            cc.total = cc.TotalChange();
            RaisePropertyChangedEvent("total");
        }
        protected void AddPenny()
        {
            cc.AddPenny();
            cc.total = cc.TotalChange();
            RaisePropertyChangedEvent("total");
        }
        protected void SaveSerialize()
        {
            cc.SerializeSave();
        }
        protected void LoadSerialize()
        {
            cc.SerializeLoad();
        }
        protected void NewSerialize()
        {
            cc.ClearCollection();
            RaisePropertyChangedEvent("total");
        }
        protected void MakeChange()
        {
            cc.MakeChange(makingchange);
            RaisePropertyChangedEvent("coins");
        }
    }
}
